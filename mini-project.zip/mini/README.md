# mini-project
Product desciption. What the product does. Features.
# Installation/ how to run
Preconditions and required software (e.g. Java version). Command to run the code (e.g. press green button in IntelliJ or terminal)
# Structure
Structure of the project. Architecture. Folder/ package structure. 
# How to contribute

- Pull requests are welcome. 
- Master branch is only for working and approved code.
- Before merging a branch with master branch, the code must be reviewed.
- Features should be developed in a separate branch.
- Make sure only one person is working on the same file at the same time.
- Commit messages should explain what you have done.
- For major changes, please discuss what you would like to change in appropriate channel.

# Useful links

[Trello](https://trello.com/b/wUUGOlSD)
