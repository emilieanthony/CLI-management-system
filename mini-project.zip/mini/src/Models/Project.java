package Models;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Project implements Serializable
{
    //attributes
    private int id;
    private String name;
    private String startDate;
    private String endDate;

    private ProductBacklog productBacklog;
    private SprintBacklog sprintBacklog;
    private ProductOwner productOwner;
    private Developer developer;
    private Task task;

    private ArrayList<Task> allTasks;
    private ArrayList<Developer> allTeamMembers;
    private ArrayList<ProductOwner> allProductOwners;
    private ArrayList<SprintBacklog> allSprintBacklogs;



    //constructor
    public Project(int id, String name,String startDate,String endDate) throws Exception
    {
        this.id = id;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;

        productBacklog = new ProductBacklog(null,null,null);
        sprintBacklog = new SprintBacklog(null,null,null);
        productOwner = new ProductOwner(null,0);
        developer = new Developer(null,0);
        task = new Task(0,0,0,null,null);

        allTasks = new ArrayList<>();
        allTeamMembers = new ArrayList<>();
        allProductOwners = new ArrayList<>();
        allSprintBacklogs = new ArrayList<>();

    }

    //all getters & setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStartDate()
    {
        return startDate;
    }

    public void setStartDate( String startDate)
    {
        this.startDate = startDate;
    }

    public String getEndDate()
    {
        return endDate;
    }

    public void setEndDate(String endDate)
    {
        this.endDate = endDate;
    }

    public Task getTaskFromSprintBacklog(int id)
    {
        for(SprintBacklog sprintBacklog : allSprintBacklogs)
        {
            return sprintBacklog.getTask(id);
        }
        return null;

    }

    public SprintBacklog getSprintBacklog() {
        return sprintBacklog;
    }

    public ProductOwner getProductOwner() {
        return productOwner;
    }

    public String printTasksFromSprintBacklog()
    {
        for(SprintBacklog sprintBacklog : allSprintBacklogs)
        {
            return sprintBacklog.printTasks();
        }
        return null;
    }

    public String printPersonalTasks(Developer member)
    {
        for(SprintBacklog sprintBacklog : allSprintBacklogs)
        {
            return sprintBacklog.printPersonalTasks(member);
        }
        return null;
    }
    public Developer getDeveloper() {
        return developer;
    }

    public Task getTask() {
        return task;
    }

    public String printTasks()
    {
        String output = "";

        for (Task task : allTasks)
        {
            output = output + task.toString();
        }
        return output;
    }

    public String printAssignedTasks(Developer member)
    {
        String output = "";

        if (allTasks == null)
        {
            output = "You have no tasks assigned.";
        }
        else
        {
            for (Task task : allTasks)
            {
                if (task.isAssigned(member))
                {
                    output = output + task.toString() + "\n";
                }
            }
        }
        return output;
    }


    public Developer getTeamMember(int id)
    {
        for (Developer member : allTeamMembers)
        {
            if (member.getId() == id)
            {
                return member;
            }
        }
        return null;
    }

    public void assignTask(int memberID, int taskID)        //This one is using method below
    {
        for(SprintBacklog sprintBacklog : allSprintBacklogs)
        {
            assignTask(getTeamMember(memberID), sprintBacklog.getTask(taskID));
        }
    }
    public ArrayList<Developer> getAllTeamMembers() {
        return allTeamMembers;
    }

    public void assignTask(Developer member, Task task)
    {
        task.getAssignedTeamMembers().add(member);
    }

    public ArrayList<ProductOwner> getAllProductOwners()
    {
        return allProductOwners;
    }

    public void setProductBacklog(ProductBacklog productBacklog) {
        this.productBacklog = productBacklog;
    }

    public ArrayList<Developer> getAllDevelopmentMembers()
    {
        return allTeamMembers;
    }
    public ArrayList<SprintBacklog> getAllSprintBacklogs() {
        return allSprintBacklogs;
    }

    public ArrayList<Task> getAllTasks()
    {
        for(SprintBacklog sprintBacklog : allSprintBacklogs)
        {
            return sprintBacklog.getAllTasks();
        }
        return null;
    }

    public ArrayList<SprintBacklog> getAllSprints()
    {
        return allSprintBacklogs;
    }

    public ProductBacklog getProductBacklog()
    {
        return productBacklog;
    }

    public void viewAllProductOwners()
    {
        for (ProductOwner productOwner : allProductOwners)
        {
            System.out.println(productOwner.toString());
        }
    }

    public void viewAllDevelopmentMembers()
    {
        for (Developer developer : allTeamMembers)
        {
            System.out.println(developer.toString());
        }
    }
    //toString

    @Override
    public String toString() {
        return "\nProject: "+ id +
                "\nName: " + name +
                "\nStart Date: " + startDate +
                "\nEnd Date: " + endDate +
                "\nProduct Backlog: " + productBacklog +
                //"\nSprint Backlog: " + sprintBacklog +
                //"\nProduct Owner: " + productOwner +
                //"\nDeveloper: " + developer +
                "\nTasks: " + allTasks +
                "\nTeam Members: " + allTeamMembers +
                "\nProduct Owners: " + allProductOwners +
                "\nSprintBacklog Backlogs: " + allSprintBacklogs;
    }
}
