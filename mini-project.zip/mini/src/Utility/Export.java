package Utility;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Export {

    public static void exportObject(Object object) {
        try (FileOutputStream fos = new FileOutputStream("File.txt")){
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(object);
            oos.close();
    }
        catch (FileNotFoundException exception){
            System.out.println("File" + object.toString() + "not found");

        }
        catch (IOException ioException){
            ioException.printStackTrace();
        }

}
}
